import numpy as np
import pandas as pd

def co_supply_chain_preparation(file_path):
    
    
    co_supply_chain_def['shipping date (DateOrders)']=pd.to_datetime(co_supply_chain_def['shipping date (DateOrders)'],format= "%m/%d/%Y %H:%M:%S", errors='coerce')
    co_supply_chain_def['shipping date (DateOrders)']=pd.to_datetime(co_supply_chain_def['shipping date (DateOrders)'],format= "%m/%d/%Y %H:%M:%S", errors='coerce')
    
    numeric_cols=["Days for shipping (real)","Days for shipment (scheduled)","Benefit per order", 
    "Sales per customer","Category Id", 
    "Department Id","Order Customer Id","Order Id",
    "Order Item Cardprod Id","Order Item Discount", "Order Item Discount Rate", "Order Item Id",
    "Order Item Product Price","Order Item Profit Ratio","Order Item Quantity", "Sales","Order Item Total",
    "Order Profit Per Order", "Product Card Id", "Product Category Id","Product Price"]

    for col in numeric_cols:
        co_supply_chain_def[col]= pd.to_numeric(co_supply_chain_def[col],errors='coerce')
    def clean_text(value):
        if pd.isna(value):
            return value
        return str(value).strip().title()
    text_cols=['Type','Delivery Status','Category Name', 'Customer City',
    'Customer Country', 'Customer Fname',
    'Customer Segment', 'Customer State', 'Customer Street','Department Name', 'Market', 'Order City', 'Order Country', 'Order Region',
    'Order State', 'Order Status', 'Product Name', 'Shipping Mode']
    for col in text_cols:
        co_supply_chain_def[col]=co_supply_chain_def[col].apply(clean_text)
    co_supply_chain_def['Order Item Id'].drop_duplicates(inplace=True)
    co_supply_chain_def['Full Location']=co_supply_chain_def['Order City']+ "," + co_supply_chain_def['Order Country']
    co_supply_chain_def['Shipping Delay']= co_supply_chain_def['Days for shipping (real)']- co_supply_chain_def['Days for shipment (scheduled)']
    co_supply_chain_def['Delay Flag']=np.where((co_supply_chain_def['Shipping Delay']>0) ,1 , 0)
    co_supply_chain_def['QTY Variability (StdDev)']=co_supply_chain_def.groupby('Product Name')['Order Item Quantity'].transform('std')
    co_supply_chain_def['Bullwhip Ratio'] = (co_supply_chain_def.groupby('Product Name')['Order Item Quantity'].transform('std') /
    co_supply_chain_def.groupby('Product Name')['Order Item Quantity'].transform('mean'))
    co_supply_chain_def['Profit Margin %']=co_supply_chain_def['Order Profit Per Order']  / co_supply_chain_def['Sales']
    co_supply_chain_def['Profit Category']=np.where((co_supply_chain_def['Order Profit Per Order']>0) ,"Profitable" , "Loss")
    co_supply_chain_def['Order Year']=co_supply_chain_def['order date (DateOrders)'].dt.year
    co_supply_chain_def['Order Month']=co_supply_chain_def['order date (DateOrders)'].dt.month_name()
    co_supply_chain_def.to_csv(r'C:\Users\HP\OneDrive\Desktop\Projects\Final_project.csv',index=False,index_label=False)

file_path=r"\C:\Users\HP\OneDrive\Desktop\Projects\Final_project.csv"


















